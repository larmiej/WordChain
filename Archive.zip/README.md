# WordChain

This is a game application designed for Alexa.

Word chain, also known as Grab on Behind, Last and First, Alpha and Omega, and The Name Game. It is a word game in which players come up with words that begin with the letter or letters that the previous word ended with. A category of words is usually chosen, there is a time limit such as five seconds, and words may not be repeated in the same game. An example chain for country would be: Spain - Niger - Russia - Argentina.